package com.example.poadcast.Editer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.poadcast.MainActivity;
import com.example.poadcast.Model.Podcast;
import com.example.poadcast.R;
import com.example.poadcast.Screens.AccountActivity;
import com.example.poadcast.Screens.PodCastDetailActivity;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class EditerMainActivity extends AppCompatActivity {
     ArrayList<Podcast> podcastArrayList=new ArrayList<Podcast>();
    RecyclerView recylerView;
    Dialog loadingDialog;
     PodcastAdapter arrayAdapter;
    Spinner spinner;
    ArrayAdapter aa;
    String schoolName;
    ArrayList<String> schoolArrayList=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editer_main);
        recylerView=findViewById(R.id.recylerView);
        recylerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        //loading dialog
        loadingDialog=new Dialog(this);
        loadingDialog.setContentView(R.layout.loading_progress_dialog);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.slider_background));
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        // add school name in arraylist
        schoolArrayList.add("Columbian College of Arts & Sciences");
        schoolArrayList.add("Corcoran School of the Arts & Design");
        schoolArrayList.add("School of Business");
        schoolArrayList.add("Graduate School of Education & Human Development");
        schoolArrayList.add("School of Engineering & Applied Science");
        schoolArrayList.add("Elliott School of International Affairs");
        schoolArrayList.add("School of Media & Public Affairs");
        schoolArrayList.add("School of Medicine & Health Sciences");
        schoolArrayList.add("School of Nursing");
        schoolArrayList.add("Graduate School of Political Management");
        schoolArrayList.add("College of Professional Studies");
        spinner=findViewById(R.id.spinner);



    }

    @Override
    protected void onStart() {
        aa = new android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_item,schoolArrayList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                schoolName=schoolArrayList.get(position);
                getData(schoolName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });
        super.onStart();
    }

    public void addPodcast(View view){
        startActivity(new Intent(this,AddPodCastActivity.class)
                .putExtra("schoolName",schoolName));
    }
    public void getData(String schoolName){
        podcastArrayList.clear();
        loadingDialog.show();
        DatabaseReference myRef=  FirebaseDatabase.getInstance().getReference().child("Podcast").child(schoolName)
                .child(Constant.getUserId(EditerMainActivity.this));
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot2:dataSnapshot.getChildren()){
                    podcastArrayList.add(new Podcast(dataSnapshot2.child("Title").getValue(String.class)
                            ,dataSnapshot2.child("Description").getValue(String.class)
                            ,dataSnapshot2.child("Status").getValue(String.class)
                            ,dataSnapshot2.child("Link").getValue(String.class)
                            ,dataSnapshot2.child("Id").getValue(String.class)
                            ,dataSnapshot2.child("EditorId").getValue(String.class)));

                }

                arrayAdapter =new PodcastAdapter();
                recylerView.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();
                loadingDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    public class PodcastAdapter extends RecyclerView.Adapter<PodcastAdapter.ImageViewHoler> {

        public PodcastAdapter(){

        }
        @NonNull
        @Override
        public PodcastAdapter.ImageViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v= LayoutInflater.from(EditerMainActivity.this).inflate(R.layout.item_podcast,parent,false);
            return  new PodcastAdapter.ImageViewHoler(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final PodcastAdapter.ImageViewHoler holder, @SuppressLint("RecyclerView") int position) {

            holder.title.setText("Title :"+podcastArrayList.get(position).getTitle());
            holder.status.setText("Status :"+podcastArrayList.get(position).getStatus());

            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    startActivity(new Intent(EditerMainActivity.this, PodCastDetailActivity.class)
                            .putExtra("link",podcastArrayList.get(position).getLink())
                            .putExtra("title",podcastArrayList.get(position).getTitle())
                            .putExtra("description",podcastArrayList.get(position).getDescription()));
                }
            });





        }

        @Override
        public int getItemCount() {
            return podcastArrayList.size();
        }

        public class ImageViewHoler extends RecyclerView.ViewHolder {
            TextView title,status;
            CardView cardView;
            public ImageViewHoler(@NonNull View itemView) {
                super(itemView);
                title=itemView.findViewById(R.id.title);
                status=itemView.findViewById(R.id.status);
                cardView=itemView.findViewById(R.id.card);
            }
        }
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.logout:
                Constant.setUserLoginStatus(EditerMainActivity.this,false);
                Constant.setEditorLoginStatus(EditerMainActivity.this,false);
                Constant.setMediaTeamLoginStatus(EditerMainActivity.this,false);
                startActivity(new Intent(EditerMainActivity.this, AccountActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}