package com.example.poadcast.Screens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.poadcast.R;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;
import com.google.firebase.database.FirebaseDatabase;

public class SubractionActivity extends AppCompatActivity {
    EditText card_number,card_exp_date,card_cvv,first_name,last_name,zipcode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subraction);
        zipcode=findViewById(R.id.zipcode);
        card_number=findViewById(R.id.card_number);
        card_exp_date=findViewById(R.id.card_exp_date);
        card_cvv=findViewById(R.id.card_cvv);
        first_name=findViewById(R.id.first_name);
        last_name=findViewById(R.id.last_name);
    }
    public void addPayment(View v){
        if(card_number.getText().toString().isEmpty()){
            card_number.setError("required");
        }
        else if(card_exp_date.getText().toString().isEmpty()){
            card_exp_date.setError("required");
        }
        else if(card_cvv.getText().toString().isEmpty()){
            card_cvv.setError("required");
        }
        else if(first_name.getText().toString().isEmpty()){
            first_name.setError("required");
        }
        else if(last_name.getText().toString().isEmpty()){
            last_name.setError("required");
        }else if(zipcode.getText().toString().isEmpty()){
            zipcode.setError("required");
        }
        else {
            // if user add all record update the subraction status
            FirebaseDatabase.getInstance().getReference("User").child(Constant.getUserId(SubractionActivity.this)).child("Subscribe").setValue("True");
            Toast.makeText(this,"thanks for Subscribe",Toast.LENGTH_LONG).show();
             startActivity(new Intent(SubractionActivity.this, UserMainActivity.class));
             finish();

        }
    }

}