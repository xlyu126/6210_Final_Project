package com.example.poadcast.Fragment;

import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.poadcast.Editer.EditerMainActivity;
import com.example.poadcast.MainActivity;
import com.example.poadcast.R;
import com.example.poadcast.Screens.AccountActivity;
import com.example.poadcast.Screens.SubractionActivity;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class LoginFragment extends Fragment {
    RadioButton btn_media_team,btn_user,btn_editor;
    private EditText etLoginEmail, etLoginPassword;
    TextView tv_new_register;
    private Dialog loadingDialog;
    private FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_login, container, false);
        btn_editor=view.findViewById(R.id.btn_editor);
        btn_media_team=view.findViewById(R.id.btn_media_team);
        btn_user=view.findViewById(R.id.btn_user);
        firebaseAuth = FirebaseAuth.getInstance();
        /////loading dialog
        loadingDialog=new Dialog(getContext());
        loadingDialog.setContentView(R.layout.loading_progress_dialog);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.slider_background));
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        etLoginEmail =view.findViewById(R.id.et_login_email);
        etLoginPassword = view.findViewById(R.id.et_login_password);
        tv_new_register=view.findViewById(R.id.tv_new_register);
        Button btnLogin = view.findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onClick(View view) {
                String email = etLoginEmail.getText().toString();
                String password = etLoginPassword.getText().toString();
                // call the validate function and then request
                if (validate(email, password)) requestLogin(email, password);
            }
        });


        tv_new_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((AccountActivity)getActivity()).showSignUpScreen();
            }
        });
        return view;
    }
    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    private boolean validate(String email, String password) {
        if (email.isEmpty()) etLoginEmail.setError("Enter email!");
        else if (!email.contains("@")||!email.contains(".")) etLoginEmail.setError("Enter valid email!");
        else if (password.isEmpty()) etLoginPassword.setError("Enter password!");
        else if (password.length()<6) etLoginPassword.setError("Password must be at least 6 characters!");
        else return true;
        return false;
    }
    private void requestLogin(String email, String password) {
        loadingDialog.show();

        if(!btn_media_team.isChecked()){
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()) {
                        loadingDialog.dismiss();
                        Toast.makeText(getContext(), "wrong mail or password" + task.getException(), Toast.LENGTH_LONG).show();
                    } else if (task.isSuccessful()) {

                        firebaseUser = firebaseAuth.getCurrentUser();
                        if (firebaseUser != null) {
                            if(btn_user.isChecked()){
                                getUserRecord();
                            }
                            else if(btn_editor.isChecked()){
                                getEditorRecord();
                            }

                        }

                    }
                }
            });
        }
        else {
            getMediaRecord();
        }

    }
       // get media team record to validate the login
    public void getMediaRecord(){
        DatabaseReference databaseReference=  FirebaseDatabase.getInstance().getReference()
                .child("MediaTeam");
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                 String email=dataSnapshot.child("Email").getValue(String.class);
                 String password=dataSnapshot.child("Password").getValue(String.class);
                if (email.equals(etLoginEmail.getText().toString()) && password.equals(etLoginPassword.getText().toString())) {
                    Constant.setUserLoginStatus(getContext(),false);
                    Constant.setEditorLoginStatus(getContext(),false);
                    Constant.setMediaTeamLoginStatus(getContext(),true);
                    startActivity(new Intent(getContext(), MainActivity.class));
                    getActivity().finish();
                }
                else {
                    loadingDialog.dismiss();
                    Toast.makeText(getContext(),"wrong email or password",Toast.LENGTH_LONG).show();

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

       // get user record
    public void getUserRecord(){

        DatabaseReference myRef=  FirebaseDatabase.getInstance().getReference()
                .child("User").child(firebaseUser.getUid());
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if(dataSnapshot.getValue()!=null){
                    // save the login user type in sharedPreferance
                    Constant.setUserLoginStatus(getContext(),true);
                    Constant.setEditorLoginStatus(getContext(),false);
                    Constant.setMediaTeamLoginStatus(getContext(),false);
                    Constant.setUserId(getContext(),dataSnapshot.child("UserId").getValue(String.class));
                    Constant.setUserName(getContext(),dataSnapshot.child("Name").getValue(String.class));
                            // move the user to user main screen  if user add the subricaption
                    if(dataSnapshot.child("Subscribe").getValue(String.class).equals("True")){
                        startActivity(new Intent(getActivity(), UserMainActivity.class));
                        getActivity().finish();
                    }
                    // otherwise move to subractpin screen
                    else  if(dataSnapshot.child("Subscribe").getValue(String.class).equals("False")){
                        startActivity(new Intent(getActivity(), SubractionActivity.class));
                        getActivity().finish();
                    }

                }
                else {
                    loadingDialog.dismiss();
                    Toast.makeText(getContext(),"you don't have access",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });





    }

    public void getEditorRecord(){
        DatabaseReference databaseReference=  FirebaseDatabase.getInstance().getReference()
                .child("Editor").child(firebaseUser.getUid());
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.getValue()!=null) {
                    Constant.setEditorLoginStatus(getContext(), true);
                    Constant.setMediaTeamLoginStatus(getContext(), false);
                    Constant.setUserLoginStatus(getContext(),false);
                    Constant.setUserName(getContext(), dataSnapshot.child("Name").getValue(String.class));
                    Constant.setUserId(getContext(), dataSnapshot.child("UserId").getValue(String.class));
                    startActivity(new Intent(getActivity(), EditerMainActivity.class));
                    getActivity().finish();
                }
                else {
                    loadingDialog.dismiss();
                    Toast.makeText(getContext(),"you don't have access",Toast.LENGTH_LONG).show();

                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}