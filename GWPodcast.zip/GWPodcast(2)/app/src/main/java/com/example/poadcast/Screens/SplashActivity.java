package com.example.poadcast.Screens;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.poadcast.Editer.EditerMainActivity;
import com.example.poadcast.MainActivity;
import com.example.poadcast.R;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread thread=new Thread(){
            @Override
            public void run() {
                try {
                    sleep(3000);
                    // if user type is edition move to editor screen
                    if(Constant.getEditorLoginStatus(SplashActivity.this)) {
                        startActivity(new Intent(SplashActivity.this, EditerMainActivity.class));
                        finish();
                    }
                    // if user type is normal move to user screen
                    else  if(Constant.getUserLoginStatus(SplashActivity.this)) {
                        startActivity(new Intent(SplashActivity.this, UserMainActivity.class));
                        finish();
                    }
                    // if user type is media move to media screen
                    else  if(Constant.getMediaTeamLoginStatus(SplashActivity.this)) {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        finish();
                    }
                     // move to the login screen
                    else {
                        startActivity(new Intent(SplashActivity.this, AccountActivity.class));
                        finish();
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();
    }
}