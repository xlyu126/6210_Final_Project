package com.example.poadcast.Fragment;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.Layout;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.poadcast.R;
import com.example.poadcast.Screens.AccountActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpFragment extends Fragment {

    private EditText etRegisterEmail, etRegisterPassword, etRegisterConfirmPassword
            ,et_register_gwid,et_user_firstname,et_user_lastname;
    private FirebaseAuth firebaseAuth;
    DatabaseReference myRef;
    TextView tv_login;
    Button btnRegister;
    private Dialog loadingDialog;
    RadioButton user_type,editor_type;
    String text="gwu.edu";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_sign_up, container, false);

        et_register_gwid=view.findViewById(R.id.et_register_gwid);
        et_user_firstname=view.findViewById(R.id.et_user_firstname);
        et_user_lastname=view.findViewById(R.id.et_user_lastname);
        /////loading dialog
        loadingDialog=new Dialog(getContext());
        loadingDialog.setContentView(R.layout.loading_progress_dialog);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.slider_background));
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        firebaseAuth = FirebaseAuth.getInstance();
        etRegisterEmail = view.findViewById(R.id.et_register_email);
        etRegisterPassword = view.findViewById(R.id.et_register_password);
        etRegisterConfirmPassword = view.findViewById(R.id.et_register_confirm_password);



        etRegisterEmail.setText(text);
        Selection.setSelection(etRegisterEmail.getText(), 0);

        etRegisterEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().endsWith(text)){
                    etRegisterEmail.setText(text);
                    Selection.setSelection(etRegisterEmail.getText(), etRegisterEmail.getText().length());
                }
            }
        });
        et_register_gwid.setText("G-");
        Selection.setSelection(et_register_gwid.getText(), et_register_gwid.getText().length());

        et_register_gwid.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(!s.toString().startsWith("G-")){
                    et_register_gwid.setText("G-");
                    Selection.setSelection(et_register_gwid.getText(), et_register_gwid.getText().length());
                }
            }
        });













        tv_login=view.findViewById(R.id.tv_login);
        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((AccountActivity)getActivity()).showLoginScreen();
            }
        });



        btnRegister = view.findViewById(R.id.btn_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onClick(View view) {
                String email = etRegisterEmail.getText().toString();
                String password = etRegisterPassword.getText().toString();
                String confirm_password = etRegisterConfirmPassword.getText().toString();
                String user_gwid =et_register_gwid.getText().toString();
                if (validate(email, password, confirm_password,user_gwid)) requestRegister(email, password);
            }
        });

        user_type=view.findViewById(R.id.user_type);
        editor_type=view.findViewById(R.id.editor_type);
        return view;

    }


    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    private boolean validate(String email, String password, String confirm_password, String user_gwid) {
        if (email.isEmpty()) etRegisterEmail.setError("Enter email!");

        else if (user_gwid.isEmpty()) et_register_gwid.setError("Required!");


        else if (et_user_firstname.getText().toString().isEmpty()) et_user_firstname.setError("Required!");
        else if (et_user_lastname.getText().toString().isEmpty()) et_user_lastname.setError("Required!");
        else if (!email.contains("@")||!email.contains(".")) etRegisterEmail.setError("Enter valid email!");
        else if (password.isEmpty()) etRegisterPassword.setError("Enter password!");
        else if (password.length()<6) etRegisterPassword.setError("Password must be at least 6 characters!");
        else if (confirm_password.isEmpty()) etRegisterConfirmPassword.setError("Enter password!");
        else if (!password.equals(confirm_password)) etRegisterConfirmPassword.setError("Password not matched!");
        else return true;
        return false;
    }

    private void requestRegister(String email, String password) {
        loadingDialog.show();
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(getCreateUserWithEmailOnClickListener(email));
    }
    private OnCompleteListener<AuthResult> getCreateUserWithEmailOnClickListener(String email) {
        return task -> {
            if (task.isSuccessful()) {
                add();
            } else {
                loadingDialog.dismiss();
                Toast.makeText(getContext(),"Registration failed!",Toast.LENGTH_LONG).show();

            }
        };
    }

    public void add(){
        String id = firebaseAuth.getCurrentUser().getUid();
        // add the record on the base of user type
        if(user_type.isChecked()){
            myRef=  FirebaseDatabase.getInstance().getReference("User").child(id);
            myRef.child("UserId").setValue(id);
            myRef.child("Subscribe").setValue("False");
            myRef.child("Mail").setValue(etRegisterEmail.getText().toString());
            myRef.child("GWID").setValue(et_register_gwid.getText().toString());
            myRef.child("Name").setValue(et_user_firstname.getText().toString()+" "+et_user_lastname.getText().toString());
        }
        else if(editor_type.isChecked()){
            myRef=  FirebaseDatabase.getInstance().getReference("Editor").child(id);
            myRef.child("UserId").setValue(id);
            myRef.child("Mail").setValue(etRegisterEmail.getText().toString());
            myRef.child("GWID").setValue(et_register_gwid.getText().toString());
            myRef.child("Name").setValue(et_user_firstname.getText().toString()+" "+et_user_lastname.getText().toString());
        }
        loadingDialog.dismiss();
        Toast.makeText(getContext(),"Registration successful",Toast.LENGTH_LONG).show();
        ((AccountActivity)getActivity()).showLoginScreen();
    }
}