package com.example.poadcast.Screens;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.poadcast.R;

public class PodCastDetailActivity extends AppCompatActivity {
              Button btn_play_audio,btn_stop_audio;
              EditText et_title,et_description;
              Uri audioLink;
    private MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pod_cast_detail);
        btn_stop_audio=findViewById(R.id.btn_stop_audio);
        btn_play_audio=findViewById(R.id.btn_play_audio);
        et_title=findViewById(R.id.et_title);
        et_description=findViewById(R.id.et_description);
        btn_play_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.start();
                btn_stop_audio.setVisibility(View.VISIBLE);
                btn_play_audio.setVisibility(View.GONE);
            }
        });
        btn_stop_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.pause();
                btn_stop_audio.setVisibility(View.GONE);
                btn_play_audio.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    protected void onStart() {
        // get data from intent
        et_description.setText(getIntent().getStringExtra("description"));
        et_title.setText(getIntent().getStringExtra("title"));
        audioLink= Uri.parse(getIntent().getStringExtra("link"));
          // set the audio to the audio player
        mediaPlayer = MediaPlayer.create(this,audioLink);
        super.onStart();
    }

    @Override
    public void onBackPressed() {
        mediaPlayer.stop();
        super.onBackPressed();
    }
}