package com.example.poadcast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.poadcast.Editer.EditerMainActivity;
import com.example.poadcast.Model.Podcast;
import com.example.poadcast.Screens.AccountActivity;
import com.example.poadcast.Screens.PodCastDetailActivity;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
     RecyclerView recylerView;
     Dialog loadingDialog;
     ArrayList<Podcast> podcastArrayList =new ArrayList<Podcast>();
    PodcastAdapter arrayAdapter;
    Spinner spinner;
    android.widget.ArrayAdapter aa;
    String schoolName;
    ArrayList<String> schoolArrayList=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recylerView=findViewById(R.id.recylerView);
        recylerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        //loading dialog
        loadingDialog=new Dialog(this);
        loadingDialog.setContentView(R.layout.loading_progress_dialog);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.slider_background));
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        // add school name in arraylist
        schoolArrayList.add("Columbian College of Arts & Sciences");
        schoolArrayList.add("Corcoran School of the Arts & Design");
        schoolArrayList.add("School of Business");
        schoolArrayList.add("Graduate School of Education & Human Development");
        schoolArrayList.add("School of Engineering & Applied Science");
        schoolArrayList.add("Elliott School of International Affairs");
        schoolArrayList.add("School of Media & Public Affairs");
        schoolArrayList.add("School of Medicine & Health Sciences");
        schoolArrayList.add("School of Nursing");
        schoolArrayList.add("Graduate School of Political Management");
        schoolArrayList.add("College of Professional Studies");
        spinner=findViewById(R.id.spinner);
        aa = new android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_item,schoolArrayList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinner.setAdapter(aa);

        // implement the spiner click linser to call the funcation when use select the school from spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                schoolName=schoolArrayList.get(position);
                // call funcation to get data from firbase
                getData(schoolName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }

    @Override
    protected void onStart() {

        super.onStart();
    }

    public void getData(String schoolName){
        podcastArrayList.clear();

        loadingDialog.show();
           // read data from the base of school type
        DatabaseReference myRef=  FirebaseDatabase.getInstance().getReference().child("Podcast").child(schoolName);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                    for(DataSnapshot dataSnapshot2:dataSnapshot1.getChildren()){
                        podcastArrayList.add(new Podcast(dataSnapshot2.child("Title").getValue(String.class)
                                ,dataSnapshot2.child("Description").getValue(String.class)
                                ,dataSnapshot2.child("Status").getValue(String.class)
                                ,dataSnapshot2.child("Link").getValue(String.class)
                                ,dataSnapshot2.child("Id").getValue(String.class)
                                ,dataSnapshot2.child("EditorId").getValue(String.class)));

                    }
                }

                arrayAdapter =new PodcastAdapter();
                recylerView.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();
                loadingDialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    public class PodcastAdapter extends RecyclerView.Adapter<PodcastAdapter.ImageViewHoler> {

        public PodcastAdapter(){

        }
        @NonNull
        @Override
        public PodcastAdapter.ImageViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v= LayoutInflater.from(MainActivity.this).inflate(R.layout.item_podcast,parent,false);
            return  new PodcastAdapter.ImageViewHoler(v);
        }

        @Override
        public void onBindViewHolder(@NonNull final PodcastAdapter.ImageViewHoler holder, @SuppressLint("RecyclerView") int position) {


              // show title and status
            holder.title.setText("Title :"+podcastArrayList.get(position).getTitle());
            holder.status.setText("Status :"+podcastArrayList.get(position).getStatus());
            // show the alert when media tem member click on any record
         holder.cardView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 final CharSequence[] options = {"View Detail","Approve", "Cancel"};
                 AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                 builder.setTitle("Podcast Status");
                 builder.setItems(options, new DialogInterface.OnClickListener() {
                     @Override
                     public void onClick(DialogInterface dialog, int item) {
                          // user select the approve option
                         if (options[item].equals("Approve")) {
                             // update the status to approved
                             FirebaseDatabase.getInstance().getReference()
                                     .child("Podcast").child(schoolName)
                                     .child(podcastArrayList.get(position).getUserid())
                                     .child(podcastArrayList.get(position).getId())
                                     .child("Status").setValue("Approved");
                            getData(schoolName);
                             dialog.dismiss();
                         } else if (options[item].equals("Cancel")) {
                             dialog.dismiss();
                             // if user click on detail
                         } else if (options[item].equals("View Detail")) {
                             // move to the detail screen and set the data using intent
                             startActivity(new Intent(MainActivity.this, PodCastDetailActivity.class)
                                     .putExtra("link",podcastArrayList.get(position).getLink())
                                     .putExtra("title",podcastArrayList.get(position).getTitle())
                                     .putExtra("description",podcastArrayList.get(position).getDescription()));
                             dialog.dismiss();
                         }

                     }
                 });
                 builder.show();
             }
         });




        }

        @Override
        public int getItemCount() {
            return podcastArrayList.size();
        }

        public class ImageViewHoler extends RecyclerView.ViewHolder {
            TextView title,status;
            CardView cardView;
            public ImageViewHoler(@NonNull View itemView) {
                super(itemView);
                title=itemView.findViewById(R.id.title);
                status=itemView.findViewById(R.id.status);
                cardView=itemView.findViewById(R.id.card);
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.logout:
                Constant.setUserLoginStatus(MainActivity.this,false);
                Constant.setEditorLoginStatus(MainActivity.this,false);
                Constant.setMediaTeamLoginStatus(MainActivity.this,false);
                startActivity(new Intent(MainActivity.this, AccountActivity.class));
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}