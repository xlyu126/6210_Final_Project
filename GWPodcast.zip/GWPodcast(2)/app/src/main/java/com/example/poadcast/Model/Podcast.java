package com.example.poadcast.Model;

public class Podcast {
    String title,description,status,link,id,userid;

    public Podcast(String title, String description, String status, String link,String id,String userid) {
        this.title = title;
        this.description = description;
        this.status = status;
        this.link = link;
        this.id=id;
        this.userid=userid;
    }

    public String getUserid() {
        return userid;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public String getLink() {
        return link;
    }
}
