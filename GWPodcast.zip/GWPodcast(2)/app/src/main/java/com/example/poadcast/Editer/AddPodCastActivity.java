package com.example.poadcast.Editer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.poadcast.R;
import com.example.poadcast.User.UserMainActivity;
import com.example.poadcast.Utils.Constant;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AddPodCastActivity extends AppCompatActivity {
         EditText et_title,et_description;
    Uri  AudioUri;
    Button btn_audio;
    StorageReference mRef;
    Dialog loadingDialog;
    String schoolName;
   ArrayAdapter aa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pod_cast);


        et_description=findViewById(R.id.et_description);
        et_title=findViewById(R.id.et_title);
        btn_audio=findViewById(R.id.btn_audio);
        mRef= FirebaseStorage.getInstance().getReference("podcast_audios");
//loading dialog
        loadingDialog=new Dialog(this);
        loadingDialog.setContentView(R.layout.loading_progress_dialog);
        loadingDialog.setCancelable(false);
        loadingDialog.getWindow().setBackgroundDrawable(getResources().getDrawable(R.drawable.slider_background));
        loadingDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        schoolName=getIntent().getStringExtra("schoolName");
    }

    public void addFile(View view){
        checkPermission();
    }
public void selectAudioFromGallery(){



    Intent audio = new Intent();
    audio.setType("audio/*");
    audio.setAction(Intent.ACTION_OPEN_DOCUMENT);
    startActivityForResult(Intent.createChooser(audio, "Select Audio"), 1);

}
            // first check the permission to access the files
    public  void checkPermission(){
        Dexter.withActivity(this)
                .withPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            selectAudioFromGallery();
                        }

                        if (report.isAnyPermissionPermanentlyDenied()) {
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {

                    }

                }).check();
    }
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.dialog_permission_title));
        builder.setMessage(getString(R.string.dialog_permission_message));
        builder.setPositiveButton(getString(R.string.go_to_settings), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                openSettings();
            }
        });
        builder.setNegativeButton(getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
//
    }
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package",AddPodCastActivity.this.getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && null != data) {
            //the selected audio.

            try {
                AudioUri = data.getData();
                btn_audio.setText("Audio Selected");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    public void savePodcast(View view){


        if(et_title.getText().toString().isEmpty()){
            et_title.setError("required");
        }
        else  if(et_description.getText().toString().isEmpty()){
            et_description.setError("required");
        }
        else  if(AudioUri==null){
            Toast.makeText(AddPodCastActivity.this,"select audio",Toast.LENGTH_LONG).show();
        }

        else {

                  // call funcation to upload the record
             uploadData();


        }
    }
    public String createFavId() throws Exception{
        return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
    }

    public void uploadData(){
        loadingDialog.show();
        try {
            String id =createFavId().substring(0,8);

            StorageReference storageReference = mRef.child(System.currentTimeMillis() + "." + getFileEx(AudioUri));
            storageReference.putFile(AudioUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                            while (!urlTask.isSuccessful()) ;
                            Uri downloadUrl = urlTask.getResult();
                            // add the record in firebase
                          DatabaseReference myRef=  FirebaseDatabase.getInstance().getReference("Podcast").child(schoolName).child(Constant.getUserId(AddPodCastActivity.this))
                                  .child(id);
                            myRef.child("EditorId").setValue(Constant.getUserId(AddPodCastActivity.this));
                            myRef.child("Id").setValue(id);
                            myRef.child("Title").setValue(et_title.getText().toString());
                            myRef.child("Description").setValue(et_description.getText().toString());
                            myRef.child("Status").setValue("Pending");
                            myRef.child("Link").setValue(downloadUrl.toString());
                            loadingDialog.dismiss();
                            Toast.makeText(AddPodCastActivity.this,"Podcast upload successful",Toast.LENGTH_LONG).show();
                           finish();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            loadingDialog.dismiss();
                            Toast.makeText(AddPodCastActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                        }
                    });
        } catch (Exception e) {
            loadingDialog.dismiss();
            e.printStackTrace();
        }


    }


    // get the extension of file
    private String getFileEx(Uri uri){
        ContentResolver cr=AddPodCastActivity.this.getContentResolver();
        MimeTypeMap mime=MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }
}